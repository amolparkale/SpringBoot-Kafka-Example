package com.kafka.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kafka.demo.entity.Quote;

public interface QuoteRepository extends JpaRepository<Quote, Integer> {

}
