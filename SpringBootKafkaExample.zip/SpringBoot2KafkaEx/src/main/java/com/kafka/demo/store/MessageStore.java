package com.kafka.demo.store;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kafka.demo.entity.Quote;
import com.kafka.demo.repo.QuoteRepository;
import com.kafka.demo.util.JsonUtil;

@Component
public class MessageStore {
	
	private static final Logger LOG = LoggerFactory.getLogger(MessageStore.class);

	@Autowired
	private QuoteRepository repo;
	
	public void createQuote(String message) {
		LOG.info("Message Received from Consumer {}",message);
		Quote quote = JsonUtil.toQuote(message);
		quote = repo.save(quote);
		LOG.info("Quote is created with id {}",quote.getId());
	}
	
	public List<Quote> fetchAllQuotes() {
		return repo.findAll();
	}
}
