package com.kafka.demo.util;

import org.springframework.stereotype.Component;

import com.kafka.demo.entity.Quote;

@Component
public class QuoteUtil {

	public String inputsToJson(
			String code,
			Double up,
			String vendor)
	{
		Quote quote = new Quote();
		quote.setCode(code);
		quote.setUnitPrice(up);
		quote.setVendor(vendor);
		return JsonUtil.toJson(quote);
	}
}
