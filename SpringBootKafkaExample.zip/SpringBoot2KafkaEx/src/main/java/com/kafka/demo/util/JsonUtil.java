package com.kafka.demo.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kafka.demo.entity.Quote;

//JDK 1.8
public interface JsonUtil {

	ObjectMapper om = new ObjectMapper();
	
	public static String toJson(Quote quote) {
		String json = null;
		try {
			json = om.writeValueAsString(quote);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}
	
	public static Quote toQuote(String json) {
		Quote quote = null;
		try {
			quote = om.readValue(json, Quote.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quote;
	}
}
