package com.kafka.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.demo.entity.Quote;
import com.kafka.demo.service.ProducerService;
import com.kafka.demo.store.MessageStore;
import com.kafka.demo.util.QuoteUtil;

@RestController
@RequestMapping("/quote")
public class QuoteRestController {

	@Autowired
	private QuoteUtil quoteUtil;

	@Autowired
	private ProducerService producerService;

	@Autowired
	private MessageStore messageStore;

	// 1. read inputs for quote creation
	// .../send?code=__&up=___&vendor=___(optional)
	@GetMapping("/send")
	public String createQuote(@RequestParam String code, @RequestParam Double up,
			@RequestParam(value = "vendor", required = false, defaultValue = "ATT") String vendor) {

		String json = quoteUtil.inputsToJson(code, up, vendor);
		producerService.sendMessage(json);
		return "Published Successfully";
	}

	// 2. view all quotes
	@GetMapping("/all")
	public List<Quote> viewAllQuotes() {
		List<Quote> quotes = messageStore.fetchAllQuotes();
		return quotes;
	}
}
